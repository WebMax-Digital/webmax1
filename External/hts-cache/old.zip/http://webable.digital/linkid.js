<br />
<b>Notice</b>:  Theme without header.php is <strong>deprecated</strong> since version 3.0.0 with no alternative available. Please include a header.php template in your theme. in <b>/nfs/c11/h08/mnt/205830/domains/webable.digital/html/webable_wordpress/wp-includes/functions.php</b> on line <b>3962</b><br />
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US" prefix="og: http://ogp.me/ns#">
<head>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Page not found | WebAble Digital</title>

<link rel="stylesheet" href="http://webable.digital/wp-content/themes/webable/style.css" type="text/css" media="screen" />
<link rel="pingback" href="http://webable.digital/xmlrpc.php" />



<title>Page not found | WebAble Digital</title>

<!-- This site is optimized with the Yoast SEO plugin v4.4 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found | WebAble Digital" />
<meta property="og:site_name" content="WebAble Digital" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="Page not found | WebAble Digital" />
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//maps.googleapis.com' />
<link rel='dns-prefetch' href='//cdnjs.cloudflare.com' />
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/webable.digital\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.10"}};
			!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),!(j.toDataURL().length<3e3)&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,65039,8205,55356,57096),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,55356,57096),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55357,56425,55356,57341,8205,55357,56507),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55357,56425,55356,57341,55357,56507),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='livicons_evolution_styles-css'  href='http://webable.digital/wp-content/plugins/livicons-evolution/assets/css/LivIconsEvo.WP.css?ver=2.4.375' type='text/css' media='all' />
<link rel='stylesheet' id='fc-form-css-css'  href='http://webable.digital/wp-content/plugins/formcraft3/assets/css/form.min.css?ver=3.2.26' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://webable.digital/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.2' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='main-css'  href='http://webable.digital/wp-content/themes/webable/assets/css/main.css?ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='sup-styles-css'  href='http://webable.digital/wp-content/themes/webable/assets/css/sup-styles.css?ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='keyframes-css'  href='http://webable.digital/wp-content/themes/webable/assets/css/keyframes.css?ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='pageTransitions-css'  href='http://webable.digital/wp-content/themes/webable/assets/css/pageTransitions.css?ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='animate-css'  href='http://webable.digital/wp-content/themes/webable/assets/css/animate.css?ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='nprogress-css'  href='http://webable.digital/wp-content/themes/webable/assets/css/nprogress.css?ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='header-css'  href='http://webable.digital/wp-content/themes/webable/assets/css/header.css?ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='footer-css'  href='http://webable.digital/wp-content/themes/webable/assets/css/footer.css?ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='svg-css'  href='http://webable.digital/wp-content/themes/webable/assets/css/svg.css?ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='style-css'  href='http://webable.digital/wp-content/themes/webable/assets/css/style.css?ver=4.7.10' type='text/css' media='all' />
<!-- This site uses the Google Analytics by MonsterInsights plugin v6.1.8 - Using Analytics tracking - https://www.monsterinsights.com/ -->
<script type="text/javascript" data-cfasync="false">
	/* Function to detect opted out users */
	function __gaTrackerIsOptedOut() {
		return document.cookie.indexOf(disableStr + '=true') > -1;
	}

	/* Disable tracking if the opt-out cookie exists. */
	var disableStr = 'ga-disable-UA-63440796-1';
	if ( __gaTrackerIsOptedOut() ) {
		window[disableStr] = true;
	}

	/* Opt-out function */
	function __gaTrackerOptout() {
	  document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
	  window[disableStr] = true;
	}

	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');

	__gaTracker('create', 'UA-63440796-1', 'auto');
	__gaTracker('set', 'forceSSL', true);
	__gaTracker('require', 'displayfeatures');
	__gaTracker('require', 'linkid', 'linkid.js');
	__gaTracker('send','pageview','/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer);
</script>
<!-- / Google Analytics by MonsterInsights -->
<script type='text/javascript' src='http://webable.digital/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://webable.digital/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var monsterinsights_frontend = {"js_events_tracking":"true","is_debug_mode":"false","download_extensions":"doc,exe,js,pdf,ppt,tgz,zip,xls","inbound_paths":"","home_url":"http:\/\/webable.digital","track_download_as":"event","internal_label":"int","hash_tracking":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend.js?ver=6.1.8'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.actions.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.carousel.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.kenburn.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.layeranimation.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.migration.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.navigation.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.parallax.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.slideanims.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.video.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='https://maps.googleapis.com/maps/api/js?key=AIzaSyDd4l4GPl6R6biW81mMwELsvtsu4oNVRN8&#038;ver=4.7.10'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/themes/webable/assets/js/jquery.smoothState.js?ver=1.0'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/themes/webable/assets/js/smoothfunctions.js?ver=1.0'></script>
<script type='text/javascript' src='http://cdnjs.cloudflare.com/ajax/libs/jquery.waitforimages/1.5.0/jquery.waitforimages.min.js?ver=1.0'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/themes/webable/assets/js/wow.js?ver=1.0'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/themes/webable/assets/js/typed.js?ver=4.7.10'></script>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/foundation/5.5.2/js/foundation.min.js?ver=1.0'></script>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/fastclick/1.0.6/fastclick.min.js?ver=1.0'></script>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.6.0/jquery.nicescroll.min.js?ver=1.0'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/themes/webable/assets/js/foundation/foundation.topbar.js?ver=1.0'></script>
<link rel='https://api.w.org/' href='http://webable.digital/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://webable.digital/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://webable.digital/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.7.10" />
<meta name="generator" content="Powered by Slider Revolution 5.4.2 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
</head>
<body class="error404">
<div id="page">

<div id="header" role="banner">
	<div id="headerimg">
		<h1><a href="http://webable.digital/">WebAble Digital</a></h1>
		<div class="description">A Digital Marketing Agency Based In Bangladesh</div>
	</div>
</div>
<hr />

<div class="wrap">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
				</header><!-- .page-header -->
				<div class="page-content">
					<p>It looks like nothing was found at this location. Maybe try a search?</p>

					<form role="search" method="get" id="searchform" class="searchform" action="http://webable.digital/">
				<div>
					<label class="screen-reader-text" for="s">Search for:</label>
					<input type="text" value="" name="s" id="s" />
					<input type="submit" id="searchsubmit" value="Search" />
				</div>
			</form>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->
		</main><!-- #main -->
	</div><!-- #primary -->
</div><!-- .wrap -->

 <div class="footer">
        <div class="center-div">
            <img src="http://webable.digital/wp-content/themes/webable/assets/images//Vector-Smart-Object.png"/>
            <div class="list">
<!--                -->                <ul class="text-align">
                    <!-- <li>
                        <a href="/pdf/WebAble_BrandElements.pdf">
                            <h7>BRAND ELEMENTS</h7>
                        </a> |&nbsp;
                    </li> -->
                    <li>
                        <a target="_blank" href="https://docs.google.com/presentation/d/1JH06dvIy3Y2B0muT-ixV2BVayt-vEPXWk9wzdg4TKJU/edit#slide=id.g1e9dce0a84_0_68">
                            <h7> COMPANY PROFILE</h7>
                        </a> |
                    </li>
                    <li>
                        <a href="http://webable.digital/bable">
                            <h7> THE BABLE BLOG</h7>
                        </a> |
                    </li>
                    <li>
                        <a href="http://webable.digital/work">
                            <h7>OUR WORK</h7>
                        </a> |
                    </li>
                    <!-- <li>
                        <a href="http://webable.digital/capabilities">
                            <h7> OUR SERVICES</h7>
                        </a> |
                    </li> -->
                    <li>
                        <a href="http://webable.digital/join">
                            <h7> JOIN THE TEAM </h7>
                        </a> |
                    </li>
                    <li>
                        <a href="http://webable.digital/contact/">
                            <h7> GET IN TOUCH </h7>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="social-icons">
                <ul class="text-align">
                    <li><a href="https://twitter.com/WebAble_Digital" target="_blank"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.linkedin.com/company/3544530?trk=tyah&amp;trkInfo=clickedVertical%3Acompany%2Cidx%3A2-1-2%" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="https://plus.google.com/+WebableBd/" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="https://www.facebook.com/WebAbleDigital?fref=ts" target="_blank"> <i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://instagram.com/webabledigital/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="https://www.pinterest.com/WebAbleDigital/" target="_blank"><i class="fa fa-pinterest"></i></a></li>
                </ul>
            </div>
            <div class="text-f">
                <h8>©2017 WEBABLE DIGITAL. ALL RIGHTS RESERVED</h8>
            </div>
        </div>
    </div>
<!-- Google Code for Remarketing Tag -->
<script type="text/javascript">
var google_tag_params = {
dynx_itemid: 'REPLACE_WITH_VALUE',
dynx_itemid2: 'REPLACE_WITH_VALUE',
dynx_pagetype: 'REPLACE_WITH_VALUE',
dynx_totalvalue: 'REPLACE_WITH_VALUE',
};
</script>
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 941485404;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/941485404/?guid=ON&amp;script=0"/>
</div>
</noscript>
</body>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/livicons-evolution/assets/js/LivIconsEvo.WP.tools.js?ver=2.4.375'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/livicons-evolution/assets/js/LivIconsEvo.WP.defaults.js?ver=48b16c0d0a8d'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/plugins/livicons-evolution/assets/js/LivIconsEvo.WP.min.js?ver=2.4.375'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/themes/webable/assets/js/nprogress.js?ver=1.0'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/themes/webable/assets/js/smil.user.js?ver=1.0'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/themes/webable/assets/js/main.js?ver=1.0'></script>
<script type='text/javascript' src='http://webable.digital/wp-content/themes/webable/assets/js/sup-topbar.min.js?ver=1.0'></script>
<script type='text/javascript' src='http://webable.digital/wp-includes/js/wp-embed.min.js?ver=4.7.10'></script>


</body>
</html>
